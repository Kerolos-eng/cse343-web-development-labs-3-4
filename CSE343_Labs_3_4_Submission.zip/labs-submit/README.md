# CSE343 Web Development — Labs 3 & 4

Two independent, browser-based JavaScript applications built for the Lab 3 and Lab 4 tasks.

**GitHub repository:** https://github.com/Kerolos-eng/cse343-web-development-labs-3-4

## Projects

- **Lab 3 — Orbit Calculator:** responsive calculator for addition, subtraction, multiplication, division, decimals, sign changes, and percentage. Includes clear, keyboard input, and divide-by-zero handling.
- **Lab 4 — Daybook Task Manager:** add, complete, filter, edit, and delete tasks; clear completed or all tasks; task totals and completion progress; persistent browser storage with `localStorage`.

## Run locally

No package installation or build step is required. Open either HTML file in a current browser:

- `lab3-calculator/index.html`
- `lab4-todo/index.html`

For a local development server, from this repository directory run:

```bash
python3 -m http.server 8000
```

Then open `http://localhost:8000/lab3-calculator/` or `http://localhost:8000/lab4-todo/`.

## Source structure

Each app uses a separate HTML, CSS, and JavaScript file. JavaScript is kept in plain browser-compatible ES6 and uses DOM selection, event listeners, functions, classes, array methods, template literals, and object spread where appropriate.

## Quick checks

```bash
node --check lab3-calculator/app.js
node --check lab4-todo/app.js
```

The accompanying `SUBMISSION_REPORT.pdf` contains screenshot evidence, a feature summary, and the GitHub repository link. Student name, ID, and section fields are left as fill-in placeholders because they were not supplied.
